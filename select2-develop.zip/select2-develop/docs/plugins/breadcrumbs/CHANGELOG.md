# v1.5.1
## xx/xx/2016

1. [](#improved)
    * Removed Grav trait in favor of `Grav::instance()`

# v1.5.0
## 07/14/2016

1. [](#improved)
    * non-routable pages are not linked

# v1.4.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.3.0
## 03/06/2015

1. [](#new)
    * Added toggle for showing home item
    * Added configurable home icon
    * Added configurable divider icon
    * Added toggle to link trailing item

# v1.2.3
## 02/05/2015

2. [](#improved)
    * Added support for HHVM

# v1.2.2
## 01/23/2015

2. [](#improved)
    * Added microdata information

# v1.2.1
## 01/09/2015

2. [](#improved)
    * NOTE: BREAKING CHANGE: Moved templates into `partials/` subfolder for consistency.

# v1.2.0
## 11/30/2014

1. [](#new)
    * ChangeLog started...
